<?php 
//Start Session
session_start();

//Create Constants to save Database Credentials
define('LOCALHOST', '127.0.0.1:3325');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'tmdb');

define('SITEURL', 'http://localhost/task-manager-project/');

?>